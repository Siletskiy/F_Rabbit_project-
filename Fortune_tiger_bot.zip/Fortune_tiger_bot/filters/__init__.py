from global_variable import dp

from .test_filter import SomeF

if __name__ == "filters":
    dp.filters_factory.bind(SomeF)
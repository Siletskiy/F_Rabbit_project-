
from pymongo.errors import DuplicateKeyError
from dotenv import load_dotenv
import os
from os.path import join, dirname
import logging.config
from bson.objectid import ObjectId
from global_variable import client


logging.basicConfig(level=logging.DEBUG)



def mongo():
    # client = pymongo.MongoClient('10.9.60.13', 27017, username='olbase', password='mongodb', authSource='OLBASE', authMechanism='DEFAULT')


    db = client.tf_angels_bot_db
    collection = db['users']
    return collection



async def is_user(user_id):

    db = client.apps_unit_db
    collection = db['Users']
    #возвращает количество найденных документов с этим id
    n = await collection.count_documents({"user_id": user_id })

    if n == 1:
        # collection.insert_one({"_id": id, "first_name": first_name, "username": username, "date": date})
        logging.debug("User is in db")
        return True
    else:
        logging.debug("User none in db")
        return False



async def all_gambling_apps_find():
    print(client.server_info())
    db = client.apps_unit_db
    gambling_apps_bot = db['android_app_data']
    apps_name_array = []
###Work
    async for i in gambling_apps_bot.find({"app_available": "200"}):
        print(i)
        count_installs = ''
        if "count_installs" in i:
            count_installs = i["count_installs"]

        list = [i["_id"], i["app_id"], i["app_name"], count_installs]
        apps_name_array.append(list)
    return apps_name_array


async def all_app_that_access_command(user_id):
    db = client.apps_unit_db
    user_collection = db['users']
    n = await user_collection.find_one({"user_id": user_id})
    print(n)
    print(n["command_id"])
    apps_name_array = []
    command_collection = db['commands']
    cmd = await command_collection.find_one({"command_id": n["command_id"]})

    print(cmd)
    # print(cmd['command_apps':['_id']])

    for i in cmd['command_apps']:
        print(i)
        list = [i["_id"], i["app_name"]]
        apps_name_array.append(list)
    return apps_name_array





async def get_gambling_apps_with_id(id):
    db = client.apps_unit_db
    gambling_apps_bot = db['android_app_data']
    apps_info = []
    print(id)
    document = await gambling_apps_bot.find_one({'_id': ObjectId(id)})
    print(type(document))
    print(document)
    return document



async def post_cabs(fb_app_id, chat_id, date, bundle_name, app_name, cabs, username, user_id, message_id, status, code_error, text_error,api_token_v2):
    logging.info(" ____________________________Готовность к отправке")
    db = client.shared_kabs
    collection = db['shared_tasks']
    try:
        res = await collection.insert_one({
                               "fb_app_id": fb_app_id,
                               "chat_id": chat_id,
                               "date": date,
                               "bundle_name":bundle_name,
                               "app_name":app_name,
                               "cabs":cabs,
                               "tg_user_nickname":username,
                               "tg_user_id":user_id,
                               "tg_message_id": message_id,
                               "status": status,
                               "code_error":code_error,
                               "text_error":text_error,
                               "api_token_v2":api_token_v2
        })

        # res = await collection.insert_one({
        #                        "fb_app_id": "fb_app_id",
        #
        # })

        print(res)
        result="Кабы отправленны в очередь на пошарку. Время ожидания: 5-10 min."
    except BaseException as exc:
        logging.debug(f"________________ОШИБКА {exc} ПУБЛИКАЦИИ КАБИНЕТОВ В БД")
        result = "Ошибка отправки"

    return result



async def add_user(user_id, username, first_name):
    print(client.server_info())
    print(user_id)
    print(username)
    print(first_name)
    db = client.apps_unit_db

    users_collection = db['Users']

    # Если юзера нет, то создаем юзера и добавляем его в команду
    user = await users_collection.find_one({"user_id": int(user_id)})
    if not user:
        print("Added new user to database and command ")
        await users_collection.insert_one({
            "first_name": first_name,
            "username": username,
            "user_id": int(user_id),
        })
        return first_name + " added to the team."








# #если ключ подошел , добавить пользователля в bd, если пользователь уже есть не добавлтьть, если другой ключ то добавить в другую команду
# async def add_user_if_keys_find(key, user_id, username, first_name):
#     print(client.server_info())
#     print(user_id)
#     print(username)
#     print(first_name)
#     db = client.apps_unit_db
#     commands_collection = db['commands']
#     users_collection = db['Users']
#
# ###Work
#     #Ищем команду по ключу
#     keys = await commands_collection.find_one({"key": key})
#
#     if keys:
#         print('keys_find')
#         #Если user уже есть в бд то провряем совпадают ли ключи, если ключи не совпадают, то меняем команду
#         #Если ключи совпали юзер уже добавлен
#         #Если юзера нет, то создаем юзера и добавляем его в команду
#         user = await users_collection.find_one({"user_id": int(user_id)})
#         print(user)
#         if user:
#             print("User already added")
#             print(user["user_id"])
#             if user["key"] == key:
#                 print("User with this keys already added in database")
#                 return "You are already added to this team"
#             elif user["key"] != key:
#                 print("Added user to other command , update key")
#                 #Удаляем юзера из предведущей команды
#                 await commands_collection.update_one({"command_id": user["command_id"]}, {'$pull': {"users_id": {"user_id": int(user["user_id"])}}})
#                 #Добавлям ключ текущий ключ для юзера и название новой команды
#                 await users_collection.update_one({"user_id": int(user_id)}, {'$set': {'key': key, 'command_id': keys["command_id"]}})
#                 #Добавляем юзера в новую команду
#                 await commands_collection.update_one({"key": key}, {'$push': {'users_id': {"user_id": int(user_id)} }})
#
#                 return "You have been added to another team"
#         else:
#             print("Added new user to database and command ")
#             await users_collection.insert_one({
#                 "first_name": first_name,
#                 "username": username,
#                 "user_id": int(user_id),
#                 "key": key,
#                 "command_id": keys["command_id"]
#             })
#             await commands_collection.update_one({"key": key}, {'$push': {'users_id': {"user_id": int(user_id)}}})
#             return first_name + " added to the team."
#
#
#         #Если user_id добавлен но введенный key не равен присутвующему, добавить новый key(перевести в новою команду)
#         # elif users_collection.find_one({"user_id": user_id}):
#         #     print("User added but keys different")
#         #Если user_id и и key нет в базе данных , добавить нового пользователя
#         # elif users_collection.find_one({"user_id": user_id}):
#
#
#     else:
#         print('not_find_keys')
#         return "This key is not valid"
    # async for i in commands_collection.find({"key": key}):
    #     print(i)
    #     print(len(i))
    #     if len(i)>0:
    #         print('keys_find')
    #
    #     else:
    #         print('not_find')


   #     list = [i["_id"], i["app_name"]]
   #     apps_name_array.append(list)
   # return apps_name_array

# async def send_shared_kabs(kabs,user, message):

    # async for i in gambling_apps_bot.find_one({"_id": "61fa2b136480e006e8d807a0"}):
    #     print(i)
    #     print(i["name"])

        # cursor = gambling_apps_bot.find({"access_gp": True})
        # cursor = gambling_apps_bot.find({"_id": "61fc2a4f6480e006e8d807a2"})
        #
        # print(cursor)
        # for name in cursor:
    #     logging.debug("++++++++++++++++++++++++++++++++")
    #     print(name)


    # async for name in collection.find({"name":"Book of Gold"}):
    #     logging.debug("User is in db")
    #     print(name)
from typing import List

from aiogram.dispatcher import  FSMContext
from aiogram.dispatcher.filters.state import State,StatesGroup
from aiogram import types, Dispatcher
from aiogram.dispatcher.handler import ctx_data
from aiogram.dispatcher.filters import Text

from db.mongo_method import get_gambling_apps_with_id, post_cabs
from global_variable import dp, bot
import re

from keyboard import cancel_inline_button
from models.sharing_cabs_model import sharing_cabs_model
from util.throttling import rate_limit

class FSM_SHARED_KABS(StatesGroup):

    kabs_list = State()

     

#@rate_limit(limit=30)
async def machine_shared_kabs_start(callback: types.CallbackQuery, state: FSMContext):
    print("machine_shared_kabs_start")

#записать данные в контекст
   # types.User.set_current()
   #  await FSM_SHARED_KABS.kabs_list.set()

    #включаем состояние получения текста и передаем ощищаный колбек в это состояяние
    await state.set_state(FSM_SHARED_KABS.kabs_list.state)
    dict_data = {"data": callback.data}
    model = sharing_cabs_model(callback_apps_id=dict_data)
    model.cleaning()
    await state.update_data(db_apps_id=model.callback_apps_id)

    await callback.message.answer(text="Введиде список кабов через Enter или пробел, например: "
                                       "201629114 176664431 312595172 238192431 71108382\n" 
                                       "или\n"
                                       "401574801736131\n"
                                       "638588697406199\n"
                                       "1184407818759982\n")


  # await callback.message.answer(text=callback.data)
    await callback.answer()


#даем возможность пользователю отменить состояние
async def cancel_state(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.edit_text("Отменено")
    await state.finish()



async def recive_list_kabs(message: types.Message, state: FSMContext):

    #получаем переданые данные, это id выбранной приллы
    data = await state.get_data()
    db_apps_id = data.get("db_apps_id")
    str_db_apps_id = db_apps_id["data"]
    print(str_db_apps_id)



    #парсим ввод пользователя
    result = re.split(r'[\s]+', message.text)
    print(result)
    print(len(result))
    count = 0
    size = len(result)
    error_position = []
    for element in result:
        count += 1
        print(element)
        print(element.isdigit())
        if(element.isdigit() == False):
            size -= 1
            error_position.append(count)

    if size < len(result):
        await message.answer(f"Найденны ошибки на позициях:_{error_position}_")
        await message.answer(f"Дупускаються только цифры и пробелы или Enter между ними", reply_markup=cancel_inline_button())

    elif size == len(result):
        if size<101:
            await message.answer(message.text)

            apps_info = await get_gambling_apps_with_id(str_db_apps_id)

            cabs = message.text
            user_id = message.from_user.id
            username = message.from_user.username
            date = message.date
            message_id = message.message_id
            chat_id = message.chat.id



            fb_app_id = apps_info["fb_app_id"]
            bundle_name = apps_info["bundle_name"]
            app_name = apps_info["app_name"]
            api_token_v2 = apps_info["api_token_v2"]

            status = "new"
            code_error = "none"
            text_error = "none"

            try:
                print(fb_app_id, chat_id, date, bundle_name, app_name, cabs, username, user_id, message_id, status, code_error, text_error, api_token_v2)
                post_share_cabs_result = await post_cabs(fb_app_id, chat_id, date, bundle_name, app_name, cabs, username, user_id, message_id, status, code_error, text_error, api_token_v2)
            except:
                post_share_cabs_result = "Eror 002. Напиши админу"
                print("Ошибка в одном из полей приллы")

            await message.answer(post_share_cabs_result)
            await state.finish()  # Выключаем состояние

        else:
            await message.answer(f"За раз можно пошарить не больше 99 кабов. Сейчас:{size} ",
                                 reply_markup=cancel_inline_button())

        # print(app_id_callback)
        # print(app_id_callback2)
        # print(app_id_callback3)
        # print(app_id_callback4)





    # print(messege.from_user.id)
    # print(messege.from_user.username)
    # print(messege.from_user.first_name)
    # print(messege.date)


# Регистрируем хендлеры

def register_handlers_shared_kabs(dp: Dispatcher):
    print("register_handlers_shared_kabs")


    # dp.register_callback_query_handler(machine_shared_kabs_start, regexp=r"\w+_sharing_cabs", state=None)
    # dp.register_callback_query_handler(cancel_state, Text(equals="sharing_cabs_cancel"), state=FSM_SHARED_KABS.kabs_list)
    # dp.register_message_handler(recive_list_kabs, state=FSM_SHARED_KABS.kabs_list)



# This is a sample Python script.
from aiogram import executor
from global_variable import dp, bot


#Коментарии да .0

async def on_startup(_):
    print("________________Бот вышел в онлайн_____________________")

# @dp.message_handler()
# async def start_message(message: types.Message):
#     await message.answer(message.text)


from handlers import handler_client
#from statemachine import machine_shared_kabs
import middlewares
#сетапим миделварь папка middlewares
# middlewares.setup(dp)
handler_client.register_handlers_client(dp)


#machine_shared_kabs.register_handlers_shared_kabs(dp)


# @app.route('/', methods=["POST"])  # localhost:5000/ - на этот адрес телеграм шлет свои сообщение
# def get_Message():
#     r = request.get_json()
#     print(request.json)
#
#     if r == None:
#         return "ok", 200
#     print(r.keys())
#     # if "callback_query" in r.keys():  # если в запросе есть callback_query
#     #     try:
#     #         chat_id = r["message"]["chat"]["id"]]
#     #         print(chat_id)
#     #         data = r["data"]  # тело сообщения
#     #         update_id = r["update_id"]  # на всякий случай ID сообщения
#     #         message_id = r["message_id"]["id"]
#     #     except:
#     #         return "ok", 200
#
#
#     # chat_id = r["message"]["chat"]["id"]
#     # bot.send_message(chat_id, "TEXT", reply_markup=main_bottom_buttons())
#
#
#
#
#
#
# # If new user - add to db
# #  is_user(request)
#
#
#
#
#
#
#     # send_message(chat_id, "Оплата прошла успешно")
#     # logging.debug(r)
#
#
# #    client = pymongo.MongoClient("mongodb://test2user:1234qwer@34.77.208.217/test2")
# #    db = client.cool_db
#
#  #   print(db.cool_collection.count())
#
#     return {"ok": True}



def main():
    executor.start_polling(dp, skip_updates=True, on_startup=on_startup)

# Press the green button in the gutter to run the script.



if __name__ == '__main__':
    main()



from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo




def main_bottom_buttons():
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, ).row(
        KeyboardButton(text="❇_ANDROID APPS_❇")
    )
    return markup



# Главные кнопки
def main_install_buttons():
#    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=1, ).row(
 #       KeyboardButton(text="❇_Instalar_❇")
 #   )
    markup = ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    markup.row(
        KeyboardButton(text="💎_Experimente_💎"),
        KeyboardButton(text="❇_Instalar_❇")
    )


    return markup


def offer_button():
    markup = InlineKeyboardMarkup()
   # markup.add(InlineKeyboardButton(text="Real Money Game", web_app=WebAppInfo(url='https://fortune-br-tiger.fun/get-bonus-reals-br?sub_id_12=getsub2-1&sub_id_13=appa-gl')))
   # markup.add(InlineKeyboardButton(text="Demo", web_app=WebAppInfo(url='https://appsunit.shn-host.ru/')))
    markup.row(
        InlineKeyboardButton(text="💰Depósito💰", web_app=WebAppInfo(
            url='https://fortune-br-tiger.fun/get-bonus-reals-br?sub_id_12=getsub2-1&sub_id_13=appa-gl')),
        InlineKeyboardButton(text="💎Demonstração💎", web_app=WebAppInfo(url='https://appsunit.shn-host.ru/'))
    )
    return markup


def install_button():
    markup = InlineKeyboardMarkup()
 #   markup.add(InlineKeyboardButton(text="Android | Google Play", url='https://play.fortune-br-tiger.vip'))
   # markup.add(InlineKeyboardButton(text="Iphone | App Store", url='https://portal-ai.live/'))
    markup.row(
        InlineKeyboardButton(text="📱Android | Google Play", url='https://play.fortune-br-tiger.vip'),
        InlineKeyboardButton(text="📱Iphone | App Store", url='https://portal-ai.live/')
    )
    return markup

def category_inline_kbr():
    markup = InlineKeyboardMarkup(row_width=2).add(
        InlineKeyboardButton(text="🎰__Gambling_Apps_List_🎰", callback_data="gambling"))
    return markup

# герируем кноки и присваеваем каждой имя : колбек , которые берем из бд
def all_apps_inline_button(list_button_name: list):

    buttons_list = []
    for i in list_button_name:
        print(i[0], i[1] )
        buttons_list.append([InlineKeyboardButton(text=i[1] + '🔹' + i[2] + '🔹' + i[3], callback_data=str(i[0]))])

    inline_markup = InlineKeyboardMarkup(inline_keyboard=buttons_list, row_width=2)
    return inline_markup
    #inline_markup = InlineKeyboardMarkup(row_width=1).add(InlineKeyboardButton(text='Нажми меня', callback_data="www"))

# присваеваем кнопке создание нейминга и расшарки переданый колбек
def create_naming_sharing_kab_markup(callback):
    markup = InlineKeyboardMarkup(row_width=2).add(InlineKeyboardButton(text="Получить Нейминг", callback_data=callback+"_recive_naming"), InlineKeyboardButton(text="Пошарить кабы fb",callback_data=callback+"_sharing_cabs"))

    return markup


def cancel_inline_button():
    markup = InlineKeyboardMarkup(row_width=2).add(InlineKeyboardButton(text="Отменить ввод", callback_data="sharing_cabs_cancel"))

    return markup
import contextvars

#from aiogram.utils.exceptions import Throttled

from db.mongo_method import all_gambling_apps_find, is_user, get_gambling_apps_with_id,add_user

from filters import SomeF
from aiogram.dispatcher.filters import Text
from global_variable import dp, bot
import logging.config


#from aiogram.dispatcher.filters import Text

import os

from keyboard import main_bottom_buttons, offer_button, all_apps_inline_button, create_naming_sharing_kab_markup, category_inline_kbr,main_install_buttons,install_button

#_______________Aiogram ______________
from aiogram import types, Dispatcher
#from aiogram.dispatcher import Dispatcher

from util.throttling import rate_limit


#global_apps_id_array = ["Book of Gold"]
#var1 = contextvars.ContextVar('var1')
#var2 = contextvars.ContextVar('var2')

async def command_start(message: types.Message,  from_filter):
    logging.debug("command_start_method")

    if not await is_user(message.from_user.id):
        logging.info(message.text)
        logging.info(message.from_user.id)
        logging.info(message.from_user.username)
        logging.info(message.from_user.first_name)




        apps_info = await add_user(message.from_user.id, message.from_user.username,
                                                message.from_user.first_name)

#----------------------------------------------Показать нижние  кнопки

    try:
        await message.answer(text="_", reply_markup=main_install_buttons())
        return {"from_handler": "Данные из хендлера"}
    except:
        await message.reply('Сработал Except')





# async def test_commands(message : types.Message):
#     await message.answer('Инлайн кнопка', reply_markup=inkb)
#
#
#

async def install_buttons(message : types.Message):
    original_message_id = message.message_id
  #  await message.answer(text="____________", reply_markup=install_button())
 #   new_message = await message.answer(text="____________", reply_markup=install_button())
    new_messega = await message.answer_photo(photo="https://appsunit.shn-host.ru/img/instalar0.png", caption="Сюда нужен текст", reply_markup=install_button())
    await message.bot.delete_message(chat_id=message.chat.id, message_id=original_message_id)

async def experimente_buttons(message : types.Message):

    original_message_id = message.message_id
    #new_message = await message.answer(text="____________", reply_markup=offer_button())
    # Удаляем исходное сообщение
    new_messega = await message.answer_photo(photo="https://appsunit.shn-host.ru/img/play.png",
                                             caption="Сюда нужен текст", reply_markup=offer_button())
    await message.bot.delete_message(chat_id=message.chat.id, message_id=original_message_id)

#@rate_limit(limit=3)
async def apps_category(message: types.Message ):
    # logging.debug(message.from_user.id)
    if await is_user(message.from_user.id):
        user_id = message.from_user.id
#        logging.info(user_id)
        await message.answer_animation(f'https://appsunit.shn-host.ru/bot_img/application1.gif', reply_markup=category_inline_kbr())


    else:
        await message.answer(f'Вы не добавленны в команду!')
   #  await message.answer('📱__Category__📲', reply_markup=category_inline_kbr())



# обращаемся в базу данных и получаем список всех приложений

async def mess_handl_all_apps(callback: types.CallbackQuery):


    global global_apps_id_array
    global_apps_id_array.clear()

#    apps_name_array = await all_app_that_access_command(callback.from_user.id)
    apps_name_array = await all_gambling_apps_find()

    # apps_name_array = await all_gambling_apps_find()

    for i in apps_name_array:
        global_apps_id_array.append(i[0])
    inline_markup = all_apps_inline_button(apps_name_array)
    app_lengths = len(apps_name_array)
    await callback.message.answer(f'  💸​🎰​🎰🎰(__📱_ {app_lengths} _📱__)💰💰💰💸', reply_markup=inline_markup)
    await callback.answer(cache_time=60)






# получаем колбек выбраной приллы и обращаемя в бд для получения данных о ней
async def change_apps_callback(callback: types.CallbackQuery):


    apps_info = await get_gambling_apps_with_id(callback.data)
    try:
        app_id = apps_info["app_id"]
        app_name = apps_info["app_name"]
        developer = apps_info["developer"]
        bundle_name = apps_info["bundle_name"]


        await callback.message.answer(text=app_id + ' ' + app_name + ' |' + developer)
        await callback.message.answer('✅👍 APPROVED APP 👍✅\n https://play.google.com/store/apps/details?id=' + bundle_name)
        #await callback.message.answer_photo(images)

       # keyboard_markup = create_naming_sharing_kab_markup(callback.data)
       # await callback.message.answer(text="✅  ✅  ✅  ✅  ✅  ---$$_$$----✅  ✅  ✅  ✅  ✅  ", reply_markup=keyboard_markup)
        await callback.answer(cache_time=60)

    except:
        logging.debug("Нет какого то из полей описания прилложения")
        await callback.message.answer("Ошибка 001: Напиши Админу")



# по Object_id отслеживаем коллбек и делаем передачу кабов в базу данных
# async def sharing_cabs(callback: types.CallbackQuery):
#     await callback.message.answer(text="Введиде список кабов, например: "
#                                        "201629114, 176664431,312595172,238192431,71108382"
#                                        "212859953,296720652,340459954275851,1122353991590313"
#                                        "340459954275851,1122353991590313,343316284163847")
#
#
#
#     await callback.answer()

# по Object_id отслеживаем коллбек и возвращаем шаблон нейминга
async def recive_naming(callback: types.CallbackQuery):
    await callback.message.answer(text="Шаблон нейминга:"
                                        "{naming_key}|/|sub_id_1={sub_id_1}&sub_id_2={sub_id_2}&sub_id_3={sub_id_3}&"
                                       "sub_id_4={sub_id_4}&sub_id_5={sub_id_5}&sub_id_6={sub_id_6}&sub_id_7={sub_id_7}&"
                                       "sub_id_8={sub_id_8}&sub_id_9={sub_id_9}&sub_id_10={sub_id_10} ")

    await callback.answer()



#     await callback.answer("Нажата инлайн кнопка", show_alert=True)



# доступ по ключу /key 893424234234123132
async def key_access(message: types.Message ):
    logging.info(message.text)
    logging.info(message.from_user.id)
    logging.info(message.from_user.username)
    logging.info(message.from_user.first_name)

    key = message.text.split(' ')

    logging.info(key[1])
    apps_info = await add_user_if_keys_find(key[1], message.from_user.id, message.from_user.username, message.from_user.first_name)
    print(apps_info)
    await message.answer(apps_info)






def register_handlers_client(dp : Dispatcher):
    dp.register_message_handler(command_start, SomeF(), commands=['start', 'help'] )

    # dp.register_message_handler(command_start, SomeF(), commands=['start', 'help'] )
    #
    # dp.register_message_handler(key_access, commands=['key'] )
    #
    dp.register_message_handler(install_buttons, Text(equals="❇_Instalar_❇"))
    dp.register_message_handler(experimente_buttons, Text(equals="💎_Experimente_💎"))
    # dp.register_message_handler(apps_category, Text(equals="❇_ANDROID APPS_❇"))
    # dp.register_callback_query_handler(mess_handl_all_apps, text="gambling")
    # # dp.register_message_handler(test_commands, commands="test")
    # dp.register_callback_query_handler(change_apps_callback, text=global_apps_id_array)
    # # dp.register_callback_query_handler(sharing_cabs, regexp=r"\w+_sharing_cabs")
    # dp.register_callback_query_handler(recive_naming, regexp=r"\w+_recive_naming")



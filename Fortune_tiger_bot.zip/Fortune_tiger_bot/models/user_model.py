import logging
from dataclasses import dataclass



#data class аналогичен указанию self.title = title

@dataclass
class user_model:
    user_id: int
    user_register_bool: bool


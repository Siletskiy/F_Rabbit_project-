import logging
from dataclasses import dataclass



#Класс модели сохраняем переменую callback_apps_id
#потом вызовом метода cleaning удаляем _sharing_cabs и получаем id по которому делаем запрос в bd

@dataclass
class sharing_cabs_model:
    callback_apps_id: dict

    def cleaning(self):
        a = self.callback_apps_id["data"].replace('_sharing_cabs', '')
        self.callback_apps_id["data"] = a
        logging.info(self.callback_apps_id["data"])

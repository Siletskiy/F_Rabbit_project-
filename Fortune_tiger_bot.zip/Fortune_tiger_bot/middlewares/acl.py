from aiogram import types

from aiogram.dispatcher.middlewares import BaseMiddleware

#прокидываем пользователей из базы данных в handler и тогда будет понятно кто из них имеет дотуп к боту
#приммер из aiogram
class ACLMiddleware(BaseMiddleware):

    async def setup_chat(self, data: dict, user: types.User):

        user_id = user.id


    #тут будем доставать юзера из бд
        #user = await User.get()

        # user = await User.get()

    #точки входа message и callbackquery_handler
    async def on_pre_proces_message(self, message: types.Message, data: dict):
        await self.setup_chat()

        # async def on_pre_callback_query(self, message: types.Message, data: dict)

     async def on_pre_proces_callback_query(self, call: types.CallbackQuery, data: dict):
        await self.setup_chat()
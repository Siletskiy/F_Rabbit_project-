from aiogram import Dispatcher

from global_variable import dp

from .throttling import ThrottlingMiddleware
from .big_brother import BigBrother




def setup(dp: Dispatcher):
  dp.middleware.setup(ThrottlingMiddleware())
 # dp.middleware.setup(BigBrother())

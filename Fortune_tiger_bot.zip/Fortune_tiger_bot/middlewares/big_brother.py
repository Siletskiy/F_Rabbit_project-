import logging

from aiogram import types
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware

from global_variable import banned_users


class BigBrother(BaseMiddleware):
    async def on_pre_process_update(self, update: types.Update, data: dict):

        #делать из этого Midellware запрос в базу данных и проверять есть ли даный пользователь там


        logging.info("____________________Новый апдейт")
        logging.info("____________________Следующая точка: Proces Update")
        data["middleware_date"] = "Это пройдет до on_post_procces_update"

        #фильтруем и выбераем нужный нам тип update

        if update.message:
            user = update.message.from_user.id
            logging.info(f"____________________update.message {user}")
        elif update.callback_query:
            user = update.callback_query.from_user.id
            logging.info(f"____________________update.callback_query: {user}")
        else:
            return

        #если мы хотим выполнить 2 хендлерра за один раз тогда делаем SkipHAndler
        #если мы хотим прекратить обработку делаем CancelHandler()

        if user in banned_users:
            logging.info(f"___________________ raise CancelHandler(): {user}")
            raise CancelHandler()


    async def on_process_update(self, update: types.Update, data: dict):
        logging.info(f"2, Procces Update, {data=}")
        logging.info(f"Следующая точка: Pre Procces Messege")


    #сюда попадает обьект не update а Message
    async  def on_pre_process_message(self,message: types.Message, data: dict):
        logging.info(f"3, Pre Procces Message, {data}")
        logging.info(f"Следующая точка: Filters")
        data["middleware_data"] = "Это пройдет в on_prоcess_message"



    # 4 Filters

    # 5
    async def on_process_message(self, message: types.Message, data: dict):
        logging.info(f"5. Process Message")
        logging.info("Следующая точка: Handler")
        data["middleware_data"] = "Это попадет в хендлер"


    # 6 точка Handler


    #7
    async def on_post_process_message(self, message: types.Message, data_from_filter: list, data: dict):
        logging.info(f"Post Process Message")
        logging.info(f"Следующая точка: Post Procce Update")


    #8
    async def on_post_process_update(self, update: types.Update, from_handler, data: dict):
        logging.info(f"8. Post Procces Update, {data}, {from_handler}")
        logging.info(f"__________Выход из хендлера__________")



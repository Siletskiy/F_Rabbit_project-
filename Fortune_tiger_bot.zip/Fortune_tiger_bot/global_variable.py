#_______________Aiogram __________
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
#-------------------------------------
import logging.config


from util.bot_util import get_from_env

storage = MemoryStorage()

#_______________Aiogram __________
bot = Bot(token=get_from_env("TELEGRAM_BOT_TOKEN"))
dp = Dispatcher(bot, storage=storage)
logging.basicConfig(level=logging.DEBUG)

#_________Mongo motor_____
import motor.motor_asyncio
host = get_from_env("MONGO_HOST")
uri = "mongodb+srv://creator808:123456789web@cluster0.fkxkafv.mongodb.net/test"
#client = motor.motor_asyncio.AsyncIOMotorClient('35.204.122.3', 27017)
client = motor.motor_asyncio.AsyncIOMotorClient(uri)




banned_users = [7028573872, 123123123]


